export function dataHojeISO() {
  return new Date().toISOString().split("T")[0];
}

export function calcularStatus(vencimento) {
  if (!vencimento) return "Ativo";

  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);

  const dataVencimento = new Date(`${vencimento}T00:00:00`);

  const diferencaDias = Math.ceil(
    (dataVencimento - hoje) / (1000 * 60 * 60 * 24)
  );

  if (diferencaDias < 0) return "Atrasado";
  if (diferencaDias <= 7) return "Vencendo";

  return "Ativo";
}

export function calcularDatas(dataInicio, meses) {
  if (!dataInicio) return {};

  const inicio = new Date(`${dataInicio}T00:00:00`);
  const vencimento = new Date(inicio);
  vencimento.setMonth(vencimento.getMonth() + meses);

  const aviso7 = new Date(vencimento);
  aviso7.setDate(aviso7.getDate() - 7);

  const aviso1 = new Date(vencimento);
  aviso1.setDate(aviso1.getDate() - 1);

  return {
    vencimento: vencimento.toISOString().split("T")[0],
    aviso7: aviso7.toISOString().split("T")[0],
    aviso1: aviso1.toISOString().split("T")[0],
  };
}

export function normalizarAluno(aluno) {
  return {
    ...aluno,
    id: aluno.id || crypto.randomUUID(),
    status: calcularStatus(aluno.vencimento),
    pagamentoRecebido: aluno.pagamentoRecebido ?? false,
    dataPagamento: aluno.dataPagamento || "",
    observacoes: aluno.observacoes || "",
    historicoPagamentos: aluno.historicoPagamentos || [],
  };
}

export function ordenarPorVencimento(alunos) {
  return [...alunos].sort((a, b) => {
    const statusA = calcularStatus(a.vencimento);
    const statusB = calcularStatus(b.vencimento);

    if (statusA === "Atrasado" && statusB !== "Atrasado") return -1;
    if (statusA !== "Atrasado" && statusB === "Atrasado") return 1;

    const dataA = a.vencimento ? new Date(`${a.vencimento}T00:00:00`) : null;
    const dataB = b.vencimento ? new Date(`${b.vencimento}T00:00:00`) : null;

    if (!dataA && !dataB) return 0;
    if (!dataA) return 1;
    if (!dataB) return -1;

    return dataA - dataB;
  });
}

export function formatarData(data) {
  if (!data) return "-";

  return new Date(`${data}T00:00:00`).toLocaleDateString("pt-BR");
}

export function formatarMoeda(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export function corStatus(status) {
  switch (status) {
    case "Ativo":
      return "#16a34a";
    case "Vencendo":
      return "#f59e0b";
    case "Atrasado":
      return "#dc2626";
    default:
      return "#6b7280";
  }
}
