import { useEffect, useMemo, useState } from "react";
import Sidebar from "../components/Sidebar";
import { planos } from "../data/planos";
import { buscarAlunos, salvarAlunos } from "../data/storage";
import {
  calcularDatas,
  calcularStatus,
  corStatus,
  dataHojeISO,
  formatarData,
  formatarMoeda,
  normalizarAluno,
  ordenarPorVencimento,
} from "../data/alunosUtils";

function Financeiro() {
  const [alunos, setAlunos] = useState(() =>
    buscarAlunos().map(normalizarAluno)
  );
  const [pagamento, setPagamento] = useState(null);

  useEffect(() => {
    salvarAlunos(alunos);
  }, [alunos]);

  const alunosOrdenados = useMemo(
    () => ordenarPorVencimento(alunos.map(normalizarAluno)),
    [alunos]
  );

  const historicoFinanceiro = useMemo(
    () =>
      alunos
        .flatMap((aluno) =>
          (aluno.historicoPagamentos || []).map((item) => ({
            ...item,
            aluno: aluno.nome,
            planoAtual: aluno.plano,
          }))
        )
        .sort((a, b) => String(b.data).localeCompare(String(a.data))),
    [alunos]
  );

  function abrirPagamento(aluno) {
    setPagamento({
      alunoId: aluno.id,
      alunoNome: aluno.nome,
      data: dataHojeISO(),
      valor: String(aluno.valor || ""),
      formaPagamento: "Pix",
    });
  }

  function renovarPlano(aluno, dadosPagamento) {
    const plano = planos[aluno.plano];

    if (!plano) return aluno;

    const datas = calcularDatas(dadosPagamento.data, plano.meses);
    const historicoAnterior = aluno.historicoPagamentos || [];
    const valorPago = Number(dadosPagamento.valor || 0);

    return normalizarAluno({
      ...aluno,
      pagamentoRecebido: true,
      dataPagamento: dadosPagamento.data,
      inicio: dadosPagamento.data,
      ...datas,
      status: calcularStatus(datas.vencimento),
      historicoPagamentos: [
        ...historicoAnterior,
        {
          id: crypto.randomUUID(),
          data: dadosPagamento.data,
          valor: valorPago,
          formaPagamento: dadosPagamento.formaPagamento,
          plano: aluno.plano,
        },
      ],
    });
  }

  function marcarPagamento() {
    if (!pagamento?.alunoId) return;

    if (!pagamento.data || Number(pagamento.valor || 0) <= 0) {
      alert("Informe a data e o valor do pagamento.");
      return;
    }

    const alunosAtualizados = alunos.map((aluno) => {
      if (aluno.id === pagamento.alunoId) return renovarPlano(aluno, pagamento);

      return normalizarAluno(aluno);
    });

    setAlunos(alunosAtualizados);
    salvarAlunos(alunosAtualizados);
    setPagamento(null);

    alert("Pagamento registrado com sucesso.");
  }

  const receitaPrevista = alunos.reduce(
    (total, aluno) => total + Number(aluno.valor || 0),
    0
  );

  const receitaRecebida = alunos.reduce((total, aluno) => {
    const historico = aluno.historicoPagamentos || [];

    return (
      total +
      historico.reduce(
        (subTotal, item) => subTotal + Number(item.valor || 0),
        0
      )
    );
  }, 0);

  const receitaPendente =
    receitaPrevista -
    alunos
      .filter((aluno) => aluno.pagamentoRecebido)
      .reduce((total, aluno) => total + Number(aluno.valor || 0), 0);

  return (
    <div style={{ display: "flex" }}>
      <Sidebar />

      <div style={conteudo}>
        <h1>Financeiro</h1>

        <div style={cardsGrid}>
          <div style={card}>
            <h3>Receita Prevista</h3>
            <p>{formatarMoeda(receitaPrevista)}</p>
          </div>

          <div style={card}>
            <h3>Receita Recebida</h3>
            <p>{formatarMoeda(receitaRecebida)}</p>
          </div>

          <div style={card}>
            <h3>Receita Pendente</h3>
            <p>{formatarMoeda(receitaPendente)}</p>
          </div>
        </div>

        <h2 style={{ marginTop: "40px" }}>Controle de Pagamentos</h2>

        <div style={{ overflowX: "auto", marginTop: "20px" }}>
          <table style={tabela}>
            <thead>
              <tr style={linhaCabecalho}>
                <th style={header}>Aluno</th>
                <th style={header}>Plano</th>
                <th style={header}>Valor</th>
                <th style={header}>Vencimento</th>
                <th style={header}>Status</th>
                <th style={header}>Último Pagamento</th>
                <th style={header}>Ações</th>
              </tr>
            </thead>

            <tbody>
              {alunosOrdenados.map((aluno) => (
                <tr key={aluno.id}>
                  <td style={celula}>{aluno.nome}</td>
                  <td style={celula}>{planos[aluno.plano]?.nome || "-"}</td>
                  <td style={celula}>{formatarMoeda(aluno.valor)}</td>
                  <td style={celula}>{formatarData(aluno.vencimento)}</td>
                  <td style={celula}>
                    <span
                      style={{
                        color: corStatus(aluno.status),
                        fontWeight: "bold",
                      }}
                    >
                      {aluno.status}
                    </span>
                  </td>
                  <td style={celula}>{formatarData(aluno.dataPagamento)}</td>
                  <td style={celula}>
                    <button
                      onClick={() => abrirPagamento(aluno)}
                      style={botaoReceber}
                    >
                      Receber
                    </button>
                  </td>
                </tr>
              ))}

              {alunosOrdenados.length === 0 && (
                <tr>
                  <td style={estadoVazio} colSpan="7">
                    Nenhum aluno cadastrado para controle financeiro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <section style={relatorioCard}>
          <div style={secaoTopo}>
            <div>
              <h2>Histórico Financeiro</h2>
              <p style={secaoLegenda}>
                Pagamentos registrados com data, valor e forma de pagamento
              </p>
            </div>
          </div>

          <div style={{ overflowX: "auto", marginTop: "20px" }}>
            <table style={tabela}>
              <thead>
                <tr style={linhaCabecalho}>
                  <th style={header}>Data</th>
                  <th style={header}>Aluno</th>
                  <th style={header}>Plano</th>
                  <th style={header}>Valor</th>
                  <th style={header}>Forma</th>
                </tr>
              </thead>

              <tbody>
                {historicoFinanceiro.map((item) => (
                  <tr key={item.id || `${item.aluno}-${item.data}-${item.valor}`}>
                    <td style={celula}>{formatarData(item.data)}</td>
                    <td style={celula}>{item.aluno}</td>
                    <td style={celula}>{planos[item.plano]?.nome || "-"}</td>
                    <td style={celula}>{formatarMoeda(item.valor)}</td>
                    <td style={celula}>{item.formaPagamento || "-"}</td>
                  </tr>
                ))}

                {historicoFinanceiro.length === 0 && (
                  <tr>
                    <td style={estadoVazio} colSpan="5">
                      Nenhum pagamento registrado no histórico.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {pagamento && (
          <div style={modalOverlay}>
            <div style={modal}>
              <div style={modalTopo}>
                <div>
                  <h2>Registrar Pagamento</h2>
                  <p style={secaoLegenda}>{pagamento.alunoNome}</p>
                </div>

                <button onClick={() => setPagamento(null)} style={botaoNeutro}>
                  Fechar
                </button>
              </div>

              <div style={formPagamento}>
                <label style={campoGrupo}>
                  <span style={labelCampo}>Data do pagamento</span>
                  <input
                    type="date"
                    value={pagamento.data}
                    onChange={(e) =>
                      setPagamento({ ...pagamento, data: e.target.value })
                    }
                    style={campo}
                  />
                </label>

                <label style={campoGrupo}>
                  <span style={labelCampo}>Valor</span>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={pagamento.valor}
                    onChange={(e) =>
                      setPagamento({ ...pagamento, valor: e.target.value })
                    }
                    style={campo}
                  />
                </label>

                <label style={campoGrupo}>
                  <span style={labelCampo}>Forma de pagamento</span>
                  <select
                    value={pagamento.formaPagamento}
                    onChange={(e) =>
                      setPagamento({
                        ...pagamento,
                        formaPagamento: e.target.value,
                      })
                    }
                    style={campo}
                  >
                    <option value="Pix">Pix</option>
                    <option value="Cartao de credito">Cartao de credito</option>
                    <option value="Cartao de debito">Cartao de debito</option>
                    <option value="Dinheiro">Dinheiro</option>
                    <option value="Transferencia">Transferencia</option>
                  </select>
                </label>

                <button onClick={marcarPagamento} style={botaoReceber}>
                  Salvar Pagamento
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const cardsGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
  gap: "20px",
  marginTop: "25px",
};

const conteudo = {
  padding: "30px",
  marginLeft: "260px",
  width: "calc(100% - 260px)",
};

const card = {
  background: "white",
  padding: "20px",
  borderRadius: "8px",
  boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
};

const relatorioCard = {
  ...card,
  marginTop: "30px",
};

const secaoTopo = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: "12px",
  flexWrap: "wrap",
};

const secaoLegenda = {
  color: "#6b7280",
  fontSize: "14px",
  marginTop: "6px",
};

const tabela = {
  width: "100%",
  borderCollapse: "collapse",
  background: "#fff",
  borderRadius: "8px",
  overflow: "hidden",
};

const linhaCabecalho = {
  background: "#111827",
  color: "#fff",
};

const header = {
  padding: "12px",
  textAlign: "left",
};

const celula = {
  padding: "12px",
  borderBottom: "1px solid #e5e7eb",
};

const estadoVazio = {
  ...celula,
  color: "#6b7280",
  textAlign: "center",
};

const botaoReceber = {
  background: "#16a34a",
  color: "white",
  border: "none",
  padding: "8px 12px",
  borderRadius: "6px",
  cursor: "pointer",
};

const botaoNeutro = {
  background: "#e5e7eb",
  color: "#111827",
  border: "none",
  padding: "8px 12px",
  borderRadius: "6px",
  cursor: "pointer",
};

const modalOverlay = {
  position: "fixed",
  inset: 0,
  zIndex: 20,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "24px",
  background: "rgba(17, 24, 39, 0.55)",
};

const modal = {
  width: "min(520px, 100%)",
  background: "white",
  borderRadius: "8px",
  padding: "24px",
  boxShadow: "0 24px 70px rgba(15, 23, 42, 0.28)",
};

const modalTopo = {
  display: "flex",
  alignItems: "flex-start",
  justifyContent: "space-between",
  gap: "16px",
};

const formPagamento = {
  display: "grid",
  gap: "14px",
  marginTop: "20px",
};

const campoGrupo = {
  display: "flex",
  flexDirection: "column",
  gap: "6px",
};

const labelCampo = {
  color: "#374151",
  fontSize: "13px",
  fontWeight: "700",
};

const campo = {
  width: "100%",
  minHeight: "42px",
  border: "1px solid #d1d5db",
  borderRadius: "8px",
  padding: "9px 11px",
  background: "white",
  color: "#111827",
  outline: "none",
};

export default Financeiro;
