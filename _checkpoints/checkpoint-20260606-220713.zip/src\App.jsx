import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Alunos from "./pages/Alunos";
import Financeiro from "./pages/Financeiro";
import Treinos from "./pages/Treinos";
import Avaliacoes from "./pages/Avaliacoes";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/alunos" element={<Alunos />} />
        <Route path="/treinos" element={<Treinos />} />
        <Route path="/avaliacoes" element={<Avaliacoes />} />
        <Route path="/financeiro" element={<Financeiro />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
