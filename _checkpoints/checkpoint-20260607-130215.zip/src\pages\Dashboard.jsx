import Sidebar from "../components/Sidebar";
import { buscarAlunos } from "../data/storage";
import {
  calcularStatus,
  formatarMoeda,
  normalizarAluno,
} from "../data/alunosUtils";

function Dashboard() {
  const alunos = buscarAlunos().map(normalizarAluno);

  const totalAlunos = alunos.length;

  const receitaPrevista = alunos.reduce(
    (total, aluno) => total + Number(aluno.valor || 0),
    0
  );

  const receitaRecebida = alunos.reduce((total, aluno) => {
    const historico = aluno.historicoPagamentos || [];

    return (
      total +
      historico.reduce(
        (subTotal, item) => subTotal + Number(item.valor || 0),
        0
      )
    );
  }, 0);

  const receitaPendente =
    receitaPrevista -
    alunos
      .filter((aluno) => aluno.pagamentoRecebido)
      .reduce((total, aluno) => total + Number(aluno.valor || 0), 0);

  const alunosVencendo = alunos.filter(
    (aluno) =>
      ["Vencendo", "Vencendo parcela"].includes(
        calcularStatus(aluno.vencimento, aluno.plano)
      )
  ).length;

  const alunosAtrasados = alunos.filter(
    (aluno) =>
      ["Atrasado", "Parcela atrasada"].includes(
        calcularStatus(aluno.vencimento, aluno.plano)
      )
  ).length;

  const receitaMensal = gerarReceitaMensal(alunos);
  const maiorReceitaMensal = Math.max(
    ...receitaMensal.map((mes) => mes.total),
    0
  );

  return (
    <div style={{ display: "flex" }}>
      <Sidebar />

      <div style={conteudo}>
        <h1>Dashboard da Consultoria</h1>

        <div style={cardsGrid}>
          <div style={card}>
            <h3>Total de Alunos</h3>
            <p style={numero}>{totalAlunos}</p>
          </div>

          <div style={card}>
            <h3>Receita Prevista</h3>
            <p style={numero}>{formatarMoeda(receitaPrevista)}</p>
          </div>

          <div style={card}>
            <h3>Receita Recebida</h3>
            <p style={numero}>{formatarMoeda(receitaRecebida)}</p>
          </div>

          <div style={card}>
            <h3>Receita Pendente</h3>
            <p style={numero}>{formatarMoeda(receitaPendente)}</p>
          </div>

          <div style={card}>
            <h3>Alunos Vencendo</h3>
            <p style={{ ...numero, color: "#f59e0b" }}>{alunosVencendo}</p>
          </div>

          <div style={card}>
            <h3>Alunos Atrasados</h3>
            <p style={{ ...numero, color: "#dc2626" }}>{alunosAtrasados}</p>
          </div>
        </div>

        <section style={graficoCard}>
          <div style={secaoTopo}>
            <h2>Receita Mensal</h2>
            <span style={secaoLegenda}>Histórico de pagamentos</span>
          </div>

          {receitaMensal.some((mes) => mes.total > 0) ? (
            <div style={grafico}>
              {receitaMensal.map((mes) => {
                const altura =
                  maiorReceitaMensal > 0
                    ? Math.max((mes.total / maiorReceitaMensal) * 100, 8)
                    : 0;

                return (
                  <div key={mes.chave} style={barraItem}>
                    <div style={barraValor}>{formatarMoeda(mes.total)}</div>
                    <div style={barraTrilho}>
                      <div style={{ ...barra, height: `${altura}%` }} />
                    </div>
                    <div style={barraLabel}>{mes.rotulo}</div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p style={estadoVazio}>
              Nenhum pagamento registrado para gerar o gráfico.
            </p>
          )}
        </section>

        <section style={resumoCard}>
          <div style={secaoTopo}>
            <h2>Resumo da Consultoria</h2>
            <span style={secaoLegenda}>Visao geral da carteira</span>
          </div>

          <div style={resumoGrid}>
            <div style={resumoItem}>
              <span style={resumoLabel}>Alunos cadastrados</span>
              <strong style={resumoValor}>{totalAlunos}</strong>
            </div>

            <div style={resumoItem}>
              <span style={resumoLabel}>Cobrancas pendentes</span>
              <strong style={{ ...resumoValor, color: "#dc2626" }}>
                {alunosAtrasados}
              </strong>
            </div>

            <div style={resumoItem}>
              <span style={resumoLabel}>Proximos do vencimento</span>
              <strong style={{ ...resumoValor, color: "#f59e0b" }}>
                {alunosVencendo}
              </strong>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

function gerarReceitaMensal(alunos) {
  const hoje = new Date();

  const meses = Array.from({ length: 6 }, (_, index) => {
    const data = new Date(hoje.getFullYear(), hoje.getMonth() - (5 - index), 1);
    const chave = data.toISOString().slice(0, 7);
    const rotulo = data.toLocaleDateString("pt-BR", {
      month: "short",
      year: "2-digit",
    });

    return {
      chave,
      rotulo: rotulo.replace(".", ""),
      total: 0,
    };
  });

  const indicePorMes = new Map(meses.map((mes, index) => [mes.chave, index]));

  alunos.forEach((aluno) => {
    (aluno.historicoPagamentos || []).forEach((pagamento) => {
      if (!pagamento.data) return;

      const chave = pagamento.data.slice(0, 7);
      const indice = indicePorMes.get(chave);

      if (indice === undefined) return;

      meses[indice].total += Number(pagamento.valor || 0);
    });
  });

  return meses;
}

const conteudo = {
  padding: "30px",
  marginLeft: "260px",
  width: "calc(100% - 260px)",
  background: "#f3f4f6",
  minHeight: "100vh",
};

const cardsGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
  gap: "20px",
  marginTop: "30px",
};

const card = {
  background: "white",
  padding: "20px",
  borderRadius: "8px",
  boxShadow: "0 2px 10px rgba(0,0,0,0.08)",
};

const numero = {
  fontSize: "28px",
  fontWeight: "bold",
  marginTop: "10px",
};

const graficoCard = {
  ...card,
  marginTop: "30px",
};

const resumoCard = {
  ...card,
  marginTop: "30px",
};

const secaoTopo = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: "12px",
  flexWrap: "wrap",
};

const secaoLegenda = {
  color: "#6b7280",
  fontSize: "14px",
};

const grafico = {
  display: "grid",
  gridTemplateColumns: "repeat(6, minmax(80px, 1fr))",
  gap: "14px",
  alignItems: "end",
  minHeight: "260px",
  marginTop: "24px",
  overflowX: "auto",
};

const barraItem = {
  display: "grid",
  gridTemplateRows: "auto 180px auto",
  gap: "8px",
  minWidth: "80px",
  textAlign: "center",
};

const barraValor = {
  color: "#374151",
  fontSize: "13px",
  fontWeight: "bold",
};

const barraTrilho = {
  display: "flex",
  alignItems: "end",
  background: "#eef2f7",
  borderRadius: "8px",
  overflow: "hidden",
};

const barra = {
  width: "100%",
  background: "#2563eb",
  borderRadius: "8px 8px 0 0",
};

const barraLabel = {
  color: "#4b5563",
  fontSize: "13px",
  textTransform: "capitalize",
};

const estadoVazio = {
  color: "#6b7280",
  marginTop: "18px",
};

const resumoGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
  gap: "12px",
  marginTop: "18px",
};

const resumoItem = {
  background: "#f9fafb",
  border: "1px solid #eef2f7",
  borderRadius: "8px",
  padding: "14px",
};

const resumoLabel = {
  display: "block",
  color: "#6b7280",
  fontSize: "13px",
  fontWeight: "700",
  marginBottom: "8px",
};

const resumoValor = {
  color: "#111827",
  fontSize: "24px",
};

export default Dashboard;
